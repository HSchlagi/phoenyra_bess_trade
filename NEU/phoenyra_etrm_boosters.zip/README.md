# Phoenyra ETRM Boosters (OpenAPI + n8n + Grafana)

## Inhalt
- `openapi/` – API-Skelette: Forecast, Grid, Risk, Credit, Billing
- `n8n_workflows/` – Beispiel-Workflows (ENTSOE → Forecast → Strategy → Order Dry-Run, Grid→Policy Reload)
- `grafana_dashboards/` – Panels für Forecast vs Actual, Backoffice KPIs, Risk/VaR & Limits

## Nutzung
1) **OpenAPI**: in Cursor AI öffnen → als Grundlage für neue Microservices verwenden.
2) **n8n**: JSON-Workflows in n8n importieren, ENV-Variablen/URLs anpassen (ENTSO-E Key).
3) **Grafana**: JSON als Dashboard importieren (Prometheus-Labels anpassen).

## Nächste Schritte
- Forecast-Service implementieren (Prophet/XGBoost), Prometheus-Metriken `pho_forecast_*` exportieren.
- Risk-Service (VaR Monte-Carlo), Metriken `pho_risk_*`.
- Backoffice-Pipeline (Settlement, Invoice) + Metriken `pho_bo_*`.

— Phoenyra Engineering, 2025-10-25
